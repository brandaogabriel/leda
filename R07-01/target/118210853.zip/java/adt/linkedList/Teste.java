package adt.linkedList;

public class Teste {

   public static void main(String args[]) {

      RecursiveDoubleLinkedListImpl<Integer> lista = new RecursiveDoubleLinkedListImpl<>();

      lista.insert(5);

      lista.insert(10);
      lista.insert(15);

   }

}
